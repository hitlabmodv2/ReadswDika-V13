# Wily Bot - WhatsApp Self-Bot

## Overview

This is a WhatsApp self-bot built using the Baileys library. It operates as a personal automation tool for WhatsApp, allowing the owner to automate various tasks like auto-reading stories, anti-delete message features, auto-typing indicators, and more. The bot connects to WhatsApp via QR code or pairing code and runs as a linked device.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Core Framework
- **Runtime**: Node.js with ES Modules (type: "module")
- **WhatsApp Connection**: Baileys v7.0.0-rc.6 - An unofficial WhatsApp Web API library that connects via WebSocket
- **Authentication**: Multi-file auth state stored in `sessions/` directory as JSON files

### Bot Features Architecture
Configuration-driven features defined in `config.json`:
- **Auto Online**: Keeps the bot appearing online at regular intervals
- **Memory Monitor**: Monitors and limits memory usage with auto-detection
- **Auto Read Story**: Automatically reads WhatsApp statuses with optional reactions
- **Auto Typing/Recording**: Simulates typing or recording indicators
- **Anti-Delete**: Captures deleted messages and forwards them to bot's own number. Supports text, images, videos, audio, stickers, and documents. Can be toggled on/off with `.antidel on/off` command. Separate settings for private chat and group chat.
- **Anti-Tag Semua Warga (AntiTagSW)**: Detects when a group member tags too many people at once (default ≥5). Automatically deletes the message, warns the user, and kicks them after reaching max warnings (default 3x). Per-group toggled via `.antitagsw on/off` command (admin only). Global toggle via `config.json` antiTagSW.enabled. Warning data stored in `data/antitagsw.json`.
- **Upload Status ke Grup (upswgc)**: Owner-only feature to broadcast a status (text/image/video/audio) to selected WhatsApp groups. Sends an interactive single-select dropdown listing all bot groups. Owner picks a target group or "Semua Grup" (all groups). Commands: `.upswgc`, `.swgc`, `.swgrup`, `.swgroup`, `.statusgrup`, `.statusgroup`. Internally uses `.sendstatus` to deliver the content. Media is base64-encoded in memory (no temp files needed). Uses `generateWAMessageFromContent` + `relayMessage` for the interactive selector UI.
- **Jadibot Manager**: Main bot owner can start/stop/list linked jadibot sessions with `.jadibot`, `.stopjadibot`, `.upbot`, and `.listjadibot`. Jadibot sends a connected notice to the command chat and linked jadibot number, schedules realtime expiry cleanup, and sends warning notifications before the active period ends. Jadibot follows the shared Auto Read Story handler and reacts to WhatsApp statuses with the green-heart tap reaction by default so the linked account UI shows the status heart as active. Status auto-read handles both phone-number and LID participants so jadibot reactions also sync `read/read-self` receipts and mark stories as read on the linked account. Status reactions are relayed directly with full device fanout and multiple status-key variants so the linked account's phone can receive the same self-reaction state as the bot socket. Jadibot sockets use the same full-history sync, retry delay, and message cache setup as the main bot for status reaction retries. `.upbot` extends from the existing expiry time so old remaining duration plus added duration is stored accurately in `data/jadibot_realtime.json`. `.listjadibot` is text-only and creates a short-lived owner-only reply flow where the owner can reply with an index or phone number to stop or extend a listed jadibot. Automatic jadibot cleanup caused by expiry, pairing timeout, or forced WhatsApp logout now moves the session folder to `jadibot_deleted/` instead of hard-deleting it, so unexpected removals leave a backup trail. A realtime jadibot health monitor runs every 60 seconds and logs folder/session health, connection close reasons, failed session loads, and failed `creds.json` writes so idle session corruption is visible in the console instead of failing silently.
- **Menu Reliability**: `.menu` is sent as text-only with the requesting user's profile photo as a lightweight preview thumbnail when available, avoiding local image/media writes. If any command hits an ENOSPC/no-space write error, the handler performs automatic temp/session cleanup and replies with a plain text recovery message.

### Download Features
- **TikTok Downloader** (`.tt`, `.tiktok`, `.ttdl`): Downloads video and audio from TikTok. Supports multiple API versions (v1, v2, v3). Also supports TikTok slide/photo posts.
- **Instagram Downloader** (`.ig`, `.igdl`): Downloads reels and posts from Instagram.
- **Facebook Downloader** (`.fb`, `.fbdl`): Downloads videos from Facebook.
- **Stickerly Pack Downloader** (`.stickerly`, `.stikerly`, `.stickly`, `.stickerpack`, `.stikerpack`): Searches Stickerly packs by keyword or accepts a Stickerly pack URL/ID, then sends the full pack as normal WhatsApp stickers for reliable delivery. Native `stickerPackMessage` card sending remains available as an experimental mode with `.stickerly native <keyword/url>`, but some WhatsApp clients reject custom pack cards with "Tidak bisa menampilkan paket stiker". Scraper lives in `src/scrape/stickerly.cjs`.
- **Tempmail Etokom** (`.tempmail`/`.tmail`, `.tminbox`, `.tmread`, `.tmwait`): Disposable email via tmail.etokom.com. `.tempmail` creates a random address or a custom one (`.tempmail name@t.etokom.com`); `.tminbox` lists messages; `.tmread <id>` shows full content; `.tmwait [seconds]` polls realtime (5s interval, default 120s timeout, max 600s) and pushes any incoming email back to the chat. Per-user session state cached in-memory in `global.__tmailSessions`. Scraper lives in `src/scrape/tmail.cjs` and handles CSRF + Laravel session cookies internally. Supported domains: `t.etokom.com`, `us.seebestdeals.com`, `gift4zone.top`.
- **Realtime Weather** (`.cuaca`, `.weather`): Looks up Indonesian area names such as "Subang Jawa Barat", "Bandung Jawa Barat", and "Jakarta Selatan" using OpenStreetMap/Nominatim geocoding with Open-Meteo realtime forecast data. Replies include current condition, temperature, feels-like temperature, humidity, rain, cloud cover, wind, pressure, UV index, sunrise/sunset, next-hour forecast, and 3-day forecast. Scraper lives in `src/scrape/cuaca.cjs`.
- **Genius Song Info** (`.genius`, `.geniussearch`, `.carilagu`, `.geniusdetail`, `.gdetail`, `.detailgenius`): Searches Genius song metadata and returns song detail by Genius ID. Scraper lives in `src/scrape/genius.cjs`.
- **WhatsMusik Song Recognition** (`.whatsmusik`, `.whatmusic`, `.wmusik`, `.tebaklagu`, `.shazam`, `.carijudullagu`): Identifies songs from replied/direct WhatsApp audio, voice notes, video, audio documents, or YouTube URLs. Uses ffmpeg normalization, multiple audio sample windows, Shazam recognition, AI audio fallback, AI version detection (original, slowed/slowmo, sped-up, remix/DJ, reverb, cover), realtime YouTube search enrichment for thumbnail/source URL, version-safe realtime YouTube voice-note audio delivery, and YouTube metadata fallback when recognition fails. Scraper lives in `src/scrape/whatsmusik.cjs`.
- **WilyAI Image Search**: Multi-image requests are sent as a single WhatsApp album package (separate images grouped as "1 of N", not a collage). Each image gets an AI-generated caption tailored to the user's request and the actual image content.
- **WilyAI Reply Media Handling**: AI media analysis resolves media from direct messages, quoted messages, view-once wrappers, and bot-sent image albums. Recently sent AI images are cached briefly in memory so replying to bot image results can still be analyzed accurately even when WhatsApp quotes the album container.
- **WilyAI Prompt Organization**: AI prompt text is centralized in `src/helper/aiPrompt.js`, including sticker-expression prompts, media analysis prompts, vision reply context prompts, image-search wait messages, album captions, and image-search history replies. `src/handler/message.js` now calls prompt builder helpers instead of storing long prompt templates inline.

### Data Storage
- **JSON-based database**: Custom `JSONDB` class for lightweight data persistence
- **Session storage**: Authentication credentials and device lists stored as JSON files in `sessions/{session_name}/`
- **Contacts/Groups cache**: Stored locally for quick access without API calls
- **Bot statistics**: Tracked in `data/bot_stats.json` including uptime and restart counts

### Command System
- Commands loaded dynamically from command files
- Each command exports: `command` (array of aliases), `description`, `example`, and `execute` function
- Owner-only commands check `isOwner` flag before execution

### Helper Modules
- `inject.js`: Extends the Baileys socket with additional functionality
- `utils.js`: Configuration loading and utility functions
- `memoryMonitor.js`: Memory usage tracking and limits
- `phoneRegion.js`: Phone number formatting with country detection
- `cleaner.js`: Temporary file management and cleanup

## External Dependencies

### WhatsApp API
- **Baileys**: Unofficial WhatsApp Web API (connects via WebSocket to WhatsApp servers)
- Requires phone pairing or QR code scan for authentication
- Session persists across restarts via stored credentials

### Telegram Integration
- Bot notifications sent to Telegram via Bot API
- Configured with token and chat ID in `config.json`
- Used for remote monitoring and alerts

### NPM Packages
- **@hapi/boom**: HTTP-friendly error objects
- **pino**: Fast JSON logger
- **qrcode-terminal**: QR code display in terminal for WhatsApp pairing
- **dotenv**: Environment variable management
- **@tobyg74/tiktok-api-dl**: TikTok video/audio downloader API (v1, v2, v3 support)

### Environment Variables
- `BOT_SESSION_NAME`: Session folder name (default: "default")
- `BOT_NUMBER_OWNER`: Owner phone number for permission checks
- `BOT_MAX_RETRIES`: Maximum reconnection attempts
- `WILY_VERBOSE_LOGS` / `BOT_DEBUG_LOG`: Set to `true` to show verbose Wily AI, image search, mention debug, and command logs. These logs are hidden by default to keep the console clean.